import React from 'react'
import "./App.css"
//componentes
import Header from './Components/Header/Header'
import Main from './Components/Main/Main'
import Footer from './Components/Footer/Footer'

const App = () => {
  return (
    <>
      <Header/>
      <Main/>
      <Footer/>
    </>
  )
}

export default App
